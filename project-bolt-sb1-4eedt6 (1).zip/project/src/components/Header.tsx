import { Bot, Code, Sparkles } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-black/95 border-b border-purple-500/20 py-6">
      <div className="container mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="w-8 h-8 text-purple-500" />
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-blue-600 bg-clip-text text-transparent">
            NEXA AI
          </h1>
        </div>
        <nav className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-gray-300 hover:text-purple-400 transition">Funktionen</a>
          <a href="#about" className="text-gray-300 hover:text-purple-400 transition">Über Uns</a>
          <a href="#contact" className="text-gray-300 hover:text-purple-400 transition">Kontakt</a>
        </nav>
      </div>
    </header>
  );
}