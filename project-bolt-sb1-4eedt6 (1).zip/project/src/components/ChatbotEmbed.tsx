import { useEffect } from 'react';
import { CHATBOT_CONFIG } from '../config/chatbot';

declare global {
  interface Window {
    Chatbot: {
      init: (config: typeof CHATBOT_CONFIG) => void;
    };
  }
}

export default function ChatbotEmbed() {
  useEffect(() => {
    const script = document.createElement('script');
    script.type = 'module';
    script.src = 'https://cdn.jsdelivr.net/npm/flowise-embed/dist/web.js';
    script.onload = () => {
      window.Chatbot?.init(CHATBOT_CONFIG);
    };
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return null;
}