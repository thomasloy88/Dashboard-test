import { Brain, MessageSquare, Zap } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-[80vh] flex items-center">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1635776062127-d379bfcba9f8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2532&q=80')] bg-cover bg-center opacity-10" />
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-purple-500 to-blue-600 bg-clip-text text-transparent">
            Die Zukunft der Kommunikation ist hier
          </h1>
          <p className="text-xl text-gray-300 mb-8">
            Erleben Sie NEXA, unseren fortschrittlichen KI-Chatbot, der Ihre Kundeninteraktion revolutioniert.
          </p>
          <div className="flex flex-wrap gap-6 mt-8">
            <div className="flex items-center gap-2 text-purple-400">
              <Brain className="w-5 h-5" />
              <span>KI-gesteuert</span>
            </div>
            <div className="flex items-center gap-2 text-blue-400">
              <MessageSquare className="w-5 h-5" />
              <span>24/7 Verfügbar</span>
            </div>
            <div className="flex items-center gap-2 text-purple-400">
              <Zap className="w-5 h-5" />
              <span>Sofortige Antworten</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}