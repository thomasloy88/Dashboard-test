import { FEATURES } from '../config/features';
import FeatureCard from './features/FeatureCard';

export default function Features() {
  return (
    <section id="features" className="py-20 bg-black/95">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 bg-gradient-to-r from-blue-400 via-purple-500 to-blue-600 bg-clip-text text-transparent">
          Unsere Funktionen
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {FEATURES.map((feature, index) => (
            <FeatureCard
              key={index}
              icon={<feature.icon className="w-6 h-6 text-purple-400" />}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
}