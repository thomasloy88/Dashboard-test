export interface ChatbotTheme {
  button: {
    backgroundColor: string;
    right: number;
    bottom: number;
    size: number;
    dragAndDrop: boolean;
    iconColor: string;
    customIconSrc: string;
    autoWindowOpen: {
      autoOpen: boolean;
      openDelay: number;
      autoOpenOnMobile: boolean;
    };
  };
  tooltip: {
    showTooltip: boolean;
    tooltipMessage: string;
    tooltipBackgroundColor: string;
    tooltipTextColor: string;
    tooltipFontSize: number;
  };
  chatWindow: {
    showTitle: boolean;
    title: string;
    titleAvatarSrc: string;
    showAgentMessages: boolean;
    welcomeMessage: string;
    errorMessage: string;
    backgroundColor: string;
    backgroundImage: string;
    height: number;
    width: number;
    fontSize: number;
    botMessage: {
      backgroundColor: string;
      textColor: string;
      showAvatar: boolean;
      avatarSrc: string;
    };
    userMessage: {
      backgroundColor: string;
      textColor: string;
      showAvatar: boolean;
      avatarSrc: string;
    };
    textInput: {
      placeholder: string;
      backgroundColor: string;
      textColor: string;
      sendButtonColor: string;
      maxChars: number;
      autoFocus: boolean;
      sendMessageSound: boolean;
      receiveMessageSound: boolean;
    };
    feedback: {
      color: string;
    };
    footer: {
      textColor: string;
      text: string;
      company: string;
      companyLink: string;
    };
  };
}