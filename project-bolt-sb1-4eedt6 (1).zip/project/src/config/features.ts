import { Brain, Gauge, Globe, Shield } from 'lucide-react';

export const FEATURES = [
  {
    icon: Brain,
    title: "KI-Technologie",
    description: "Modernste künstliche Intelligenz für präzise und relevante Antworten"
  },
  {
    icon: Shield,
    title: "Sicher & Zuverlässig",
    description: "Höchste Sicherheitsstandards für Ihre Daten"
  },
  {
    icon: Globe,
    title: "Mehrsprachig",
    description: "Unterstützt multiple Sprachen für globale Kommunikation"
  },
  {
    icon: Gauge,
    title: "Schnelle Antworten",
    description: "Sofortige Reaktionen auf Kundenanfragen"
  }
] as const;