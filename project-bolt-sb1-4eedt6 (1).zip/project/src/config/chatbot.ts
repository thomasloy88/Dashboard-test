import { ChatbotTheme } from '../types/chatbot';

export const CHATBOT_CONFIG = {
  chatflowid: "5f8e2e89-b43d-4d11-8eee-6ddefa6f042c",
  apiHost: "https://flowiseai-lt-u24277.vm.elestio.app",
  chatflowConfig: {},
  theme: {
    button: {
      backgroundColor: "#03358c",
      right: 20,
      bottom: 20,
      size: 48,
      dragAndDrop: true,
      iconColor: "Cyan",
      customIconSrc: "https://i.ibb.co/fky6VW6/LT-Logo.webp",
      autoWindowOpen: {
        autoOpen: false,
        openDelay: 0,
        autoOpenOnMobile: false,
      },
    },
    tooltip: {
      showTooltip: true,
      tooltipMessage: 'Hi ich bin NEXA!',
      tooltipBackgroundColor: 'black',
      tooltipTextColor: 'white',
      tooltipFontSize: 16,
    },
    chatWindow: {
      showTitle: true,
      title: 'NEXA',
      titleAvatarSrc: 'https://i.ibb.co/fky6VW6/LT-Logo.webp',
      showAgentMessages: true,
      welcomeMessage: 'Hi, Mein Name ist NEXA, wie kann ich ihnen weiterhelfen?',
      errorMessage: 'This is a custom error message',
      backgroundColor: "black",
      backgroundImage: 'https://i.ibb.co/Cs927nr/Chat-backgound.png',
      height: 600,
      width: 400,
      fontSize: 16,
      botMessage: {
        backgroundColor: "#76dbf4",
        textColor: "#303235",
        showAvatar: true,
        avatarSrc: "https://i.ibb.co/y6G0Dsp/NEXA-chatbot-real.png",
      },
      userMessage: {
        backgroundColor: "#3B83f7",
        textColor: "#ffffff",
        showAvatar: true,
        avatarSrc: "https://raw.githubusercontent.com/zahidkhawaja/langchain-chat-nextjs/main/public/usericon.png",
      },
      textInput: {
        placeholder: 'Hier Tippen',
        backgroundColor: '#dbf1ff',
        textColor: '#303235',
        sendButtonColor: '#0c3cac',
        maxChars: 100,
        autoFocus: true,
        sendMessageSound: true,
        receiveMessageSound: true,
      },
      feedback: {
        color: '#303235',
      },
      footer: {
        textColor: '#7dd8ce',
        text: 'Powered by',
        company: 'LT AI-Solutions',
        companyLink: 'https://www.lt-ai-solutions.de/',
      }
    }
  } as ChatbotTheme
};