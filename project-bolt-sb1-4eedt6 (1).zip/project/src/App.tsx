import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import ChatbotEmbed from './components/ChatbotEmbed';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <Hero />
      <Features />
      <ChatbotEmbed />
    </div>
  );
}

export default App;